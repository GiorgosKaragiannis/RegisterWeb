import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import java.io.*;
import java.net.InetSocketAddress;
import java.util.*;

public class RegisterWeb {

    static final int MAX_LIMIT = 1_000_000_000;
    static final long TIME_LIMIT_MS = 60000;

    public static void main(String[] args) throws IOException {
        int port = 8000;
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);

        server.createContext("/solve", new SolveHandler());

        server.setExecutor(null);
        System.out.println("Server started! Listening on: http://localhost:" + port);
        server.start();
    }

    static class SolveHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange t) throws IOException {
            t.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
            t.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");

            if (t.getRequestMethod().equalsIgnoreCase("OPTIONS")) {
                t.sendResponseHeaders(204, -1);
                return;
            }

            Map<String, String> params = queryToMap(t.getRequestURI().getQuery());
            String method = params.getOrDefault("method", "astar");
            int start = Integer.parseInt(params.getOrDefault("start", "2"));
            int target = Integer.parseInt(params.getOrDefault("target", "20"));

            System.out.println("Request received: " + method + " (" + start + " -> " + target + ")");

            long startTime = System.currentTimeMillis();
            Node result = null;

            switch (method) {
                case "bfs": result = solveBFS(start, target, startTime); break;
                case "best": result = solveBestFirst(start, target, startTime); break;
                case "astar": result = solveAStar(start, target, startTime); break;
                case "dfs": result = solveDFS(start, target, startTime); break;
            }

            String response;
            if (result == null) {
                response = "No solution found or time limit exceeded.";
            } else {
                LinkedList<String> steps = new LinkedList<>();
                Node current = result;
                while (current.parent != null) {
                    steps.addFirst("-> " + current.operation + " -> " + current.value + " (Cost: " + current.operationCost + ")");
                    current = current.parent;
                }

                StringBuilder sb = new StringBuilder();
                sb.append("Solution Found!\n");
                sb.append("Steps: ").append(steps.size()).append(" | Total Cost: ").append((int)result.costFromStart).append("\n\n");
                for (String step : steps) sb.append(step).append("\n");
                response = sb.toString();
            }

            byte[] responseBytes = response.getBytes("UTF-8");
            t.sendResponseHeaders(200, responseBytes.length);
            OutputStream os = t.getResponseBody();
            os.write(responseBytes);
            os.close();
        }
    }

    private static Map<String, String> queryToMap(String query) {
        Map<String, String> result = new HashMap<>();
        if (query == null) return result;
        for (String param : query.split("&")) {
            String[] entry = param.split("=");
            if (entry.length > 1) result.put(entry[0], entry[1]);
        }
        return result;
    }

    static class Node implements Comparable<Node> {
        int value;
        double costFromStart;
        double heuristic;
        Node parent;
        String operation;
        int operationCost;

        public Node(int value, double costFromStart, double heuristic, Node parent, String operation, int operationCost) {
            this.value = value;
            this.costFromStart = costFromStart;
            this.heuristic = heuristic;
            this.parent = parent;
            this.operation = operation;
            this.operationCost = operationCost;
        }

        @Override
        public int compareTo(Node other) {
            return Double.compare(this.costFromStart + this.heuristic, other.costFromStart + other.heuristic);
        }
    }

    static List<Object[]> getNeighbors(int val) {
        List<Object[]> neighbors = new ArrayList<>();
        if (val < MAX_LIMIT) neighbors.add(new Object[]{"increase", val + 1, 2});
        if (val > 0) neighbors.add(new Object[]{"decrease", val - 1, 2});
        if (val > 0 && 2L * val <= MAX_LIMIT) neighbors.add(new Object[]{"double", val * 2, (int)Math.ceil(val/2.0)+1});
        if (val > 0) neighbors.add(new Object[]{"half", val / 2, (int)Math.ceil(val/4.0)+1});
        if (val > 0 && (long)val*val <= MAX_LIMIT) neighbors.add(new Object[]{"square", val * val, (int)Math.ceil(((long)val*val - val)/4.0)+1});
        if (val > 1) {
            double root = Math.sqrt(val);
            if (root == Math.floor(root)) neighbors.add(new Object[]{"root", (int)root, (int)Math.ceil((val-(int)root)/4.0)+1});
        }
        return neighbors;
    }

    static double calculateHeuristic(int current, int target) {
        return Math.abs(target - current);
    }

    static Node solveBFS(int start, int target, long startTime) {
        Queue<Node> queue = new LinkedList<>();
        Set<Integer> visited = new HashSet<>();
        queue.add(new Node(start, 0, 0, null, null, 0));
        visited.add(start);

        while (!queue.isEmpty()) {
            if (System.currentTimeMillis() - startTime > TIME_LIMIT_MS) return null;
            Node current = queue.poll();
            if (current.value == target) return current;

            for (Object[] move : getNeighbors(current.value)) {
                int nextVal = (Integer)move[1];
                int cost = (Integer)move[2];
                if (!visited.contains(nextVal)) {
                    visited.add(nextVal);
                    queue.add(new Node(nextVal, current.costFromStart + cost, 0, current, (String)move[0], cost));
                }
            }
        }
        return null;
    }

    static Node solveBestFirst(int start, int target, long startTime) {
        PriorityQueue<Node> pq = new PriorityQueue<>(Comparator.comparingDouble(n -> n.heuristic));
        Set<Integer> visited = new HashSet<>();
        pq.add(new Node(start, 0, calculateHeuristic(start, target), null, null, 0));
        visited.add(start);

        while (!pq.isEmpty()) {
            if (System.currentTimeMillis() - startTime > TIME_LIMIT_MS) return null;
            Node current = pq.poll();
            if (current.value == target) return current;

            for (Object[] move : getNeighbors(current.value)) {
                int nextVal = (Integer)move[1];
                int cost = (Integer)move[2];
                if (!visited.contains(nextVal)) {
                    visited.add(nextVal);
                    pq.add(new Node(nextVal, current.costFromStart + cost, calculateHeuristic(nextVal, target), current, (String)move[0], cost));
                }
            }
        }
        return null;
    }

    static Node solveAStar(int start, int target, long startTime) {
        PriorityQueue<Node> pq = new PriorityQueue<>();
        Map<Integer, Double> visitedCosts = new HashMap<>();
        pq.add(new Node(start, 0, calculateHeuristic(start, target), null, null, 0));
        visitedCosts.put(start, 0.0);

        while (!pq.isEmpty()) {
            if (System.currentTimeMillis() - startTime > TIME_LIMIT_MS) return null;
            Node current = pq.poll();
            if (current.value == target) return current;

            for (Object[] move : getNeighbors(current.value)) {
                int nextVal = (Integer)move[1];
                int cost = (Integer)move[2];
                double newG = current.costFromStart + cost;
                if (!visitedCosts.containsKey(nextVal) || newG < visitedCosts.get(nextVal)) {
                    visitedCosts.put(nextVal, newG);
                    pq.add(new Node(nextVal, newG, calculateHeuristic(nextVal, target), current, (String)move[0], cost));
                }
            }
        }
        return null;
    }

    static Node solveDFS(int start, int target, long startTime) {
        Stack<Node> stack = new Stack<>();
        Map<Integer, Double> visitedMinCost = new HashMap<>();
        stack.push(new Node(start, 0, 0, null, null, 0));
        visitedMinCost.put(start, 0.0);

        while (!stack.isEmpty()) {
            if (System.currentTimeMillis() - startTime > TIME_LIMIT_MS) return null;
            Node current = stack.pop();
            if (current.value == target) return current;

            List<Object[]> neighbors = getNeighbors(current.value);
            Collections.reverse(neighbors);
            for (Object[] move : neighbors) {
                int nextVal = (Integer)move[1];
                int cost = (Integer)move[2];
                double newTotalCost = current.costFromStart + cost;
                if (!visitedMinCost.containsKey(nextVal) || visitedMinCost.get(nextVal) > newTotalCost) {
                    visitedMinCost.put(nextVal, newTotalCost);
                    stack.push(new Node(nextVal, newTotalCost, 0, current, (String)move[0], cost));
                }
            }
        }
        return null;
    }
}